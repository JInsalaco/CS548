package edu.stevens.cs548.clinic.domain;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2020-03-10T21:54:17.894-0400")
@StaticMetamodel(SurgeryTreatment.class)
public class SurgeryTreatment_ {
	public static volatile SingularAttribute<SurgeryTreatment, Date> surgeryDate;
}
