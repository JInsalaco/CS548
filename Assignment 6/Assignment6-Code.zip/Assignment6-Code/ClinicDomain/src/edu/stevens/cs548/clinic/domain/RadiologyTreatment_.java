package edu.stevens.cs548.clinic.domain;

import javax.annotation.Generated;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-09-30T10:57:05.263-0400")
@StaticMetamodel(RadiologyTreatment.class)
public class RadiologyTreatment_ {
}
