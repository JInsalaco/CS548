package edu.stevens.cs548.clinic.domain;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2021-03-20T22:04:30.126-0400")
@StaticMetamodel(RadiologyTreatment.class)
public class RadiologyTreatment_ extends Treatment_ {
	public static volatile ListAttribute<RadiologyTreatment, Date> treatmentDates;
}
